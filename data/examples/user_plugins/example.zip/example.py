#!/usr/bin/python3

"""
# File: example.py
# Author: Tomás Vírseda
# License: GPL v3
# Description: Example of MiAZuser plugin
"""

import os
import html

from gi.repository import GObject
from gi.repository import Peas

from MiAZ.backend.log import MiAZLog


class MiAZExamplePlugin(GObject.GObject, Peas.Activatable):
    __gtype_name__ = 'MiAZExamplePlugin'
    object = GObject.Property(type=GObject.Object)

    def __init__(self):
        self.log = MiAZLog('Plugin.Example')

    def do_activate(self):
        self.app = self.object.app
        self.srvthm = self.app.get_service('theme')
        self.srvutl = self.app.get_service('util')
        self.srvpmg = self.app.get_service('plugin-manager')
        self.srvfty = self.app.get_service('factory')
        self.srvimg = self.app.get_service('icons')
        self.srvdlg = self.app.get_service('dialogs')
        plugin_name, module_ext = self.srvutl.filename_details(__file__)
        ENV = self.app.get_env()
        PLUGRES = os.path.join(ENV['LPATH']['PLUGRES'], plugin_name)
        PLUGIN_ICON_DIR = os.path.join(PLUGRES, 'icons')
        self.srvthm.add_search_path(PLUGIN_ICON_DIR)
        view = self.app.get_widget('workspace-view')
        self.add_toolbar_button()

    def do_deactivate(self):
        # Remove button
        toolbar = self.app.get_widget('headerbar-right-box')
        button = self.app.get_widget('toolbar-top-button-example')
        toolbar.remove(button)
        self.app.remove_widget('toolbar-top-button-example')

    def add_toolbar_button(self, *args):
        button = self.app.get_widget('toolbar-top-button-example')
        if button is None:
            toolbar_top_right = self.app.get_widget('headerbar-right-box')
            button = self.srvfty.create_button(icon_name='help-faq', callback=self.callback)
            button.set_visible(True)
            self.app.add_widget('toolbar-top-button-example', button)
            toolbar_top_right.append(button)
        else:
            button.set_visible(True)

    def callback(self, *args):
        plugin_name, module_ext = self.srvutl.filename_details(__file__)
        plugin = self.srvpmg.get_plugin_info(plugin_name)
        ENV = self.app.get_env()
        PLUGRES = os.path.join(ENV['LPATH']['PLUGRES'], plugin_name)
        image = self.srvimg.get_image_by_name('example')
        image.set_pixel_size(128)
        window = self.app.get_widget('window')
        dtype = 'info'
        title = "Plugin example for MiAZ"
        text = "<big>"
        text += f"<b>Plugin</b>: {plugin.get_name()} v{plugin.get_version()}\n"
        text += f"<b>Author(s)</b>:  {html.escape(', '.join(plugin.get_authors()))}\n"
        text += f"<b>Copyright</b>: {plugin.get_copyright()}"
        text += "</big>"
        # ~ text = f'CSS file exists? {CSS_EXISTS}'
        dialog = self.srvdlg.create(parent=window, dtype=dtype, title=title, body=text, widget=image)
        dialog.present()
