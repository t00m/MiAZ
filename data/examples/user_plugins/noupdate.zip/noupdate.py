#!/usr/bin/python3
# -*- coding: utf-8 -*-

"""
# File: noupdate.py
# Author: Tomás Vírseda
# License: GPL v3
# Description: Test. Disable workspace view update
"""

import tempfile
from gettext import gettext as _

from gi.repository import GObject
from gi.repository import Peas

from MiAZ.backend.log import get_logger
from MiAZ.frontend.desktop.widgets.workspace import MiAZWorkspace


class MiAZToolbarNoUpdatePlugin(GObject.GObject, Peas.Activatable):
    __gtype_name__ = 'MiAZToolbarNoUpdatePlugin'
    object = GObject.Property(type=GObject.Object)

    def __init__(self):
        self.log = get_logger('Plugin.NoUpdate')

    def do_activate(self):
        API = self.object
        self.app = API.app
        # ~ self.factory = self.app.get_service('factory')
        workspace = self.app.get_widget('workspace')
        self.log.debug(workspace.update)
        self.original_update = workspace.update
        MiAZWorkspace.update = self.noupdate
        # ~ self.add_toolbar_button()
        self.log.debug(workspace.update)

    def do_deactivate(self):
        # Remove button
        # ~ toolbar = self.app.get_widget('headerbar-right-box')
        # ~ button = self.app.get_widget('toolbar-top-button-noupdate')
        # ~ toolbar.remove(button)
        # ~ self.app.remove_widget('toolbar-top-button-noupdate')
        workspace = self.app.get_widget('workspace')
        MiAZWorkspace.update = self.original_update

    def add_toolbar_button(self, *args):
        button = self.app.get_widget('toolbar-top-button-noupdate')
        if button is None:
            toolbar_top_right = self.app.get_widget('headerbar-right-box')
            button = self.factory.create_button_toggle(icon_name='view-refresh', callback=self.callback)
            button.set_visible(True)
            self.app.add_widget('toolbar-top-button-noupdate', button)
            toolbar_top_right.append(button)
        else:
            button.set_visible(True)
        # ~ workspace = self.app.get_widget('workspace')
        # ~ self.log.debug(workspace.update)
        # ~ workspace.update = self.noupdate
        # ~ self.log.debug(workspace.update)

    def callback(self, *args):
        self.log.debug("callback")

    def noupdate(self, *args):
        self.log.debug("I don't want to update this view")
